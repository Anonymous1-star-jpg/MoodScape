Moodscape: Emotion-Driven Terrain Synthesis for Virtual Reality Systems


Video Overview: Mood-Based Terrain Generation In the video, we demonstrate the functionality of the VR system, where users can input mood parameters (Valence and Arousal) via a UI panel using a controller. Based on the selected mood values, the system generates a terrain that corresponds to the emotional state. The UI panel also offers additional options, such as selecting specific terrain types for direct generation and an option to play music. While the music selection feature, which generates terrain based on the mood of the music, is beyond the scope of this journal, it adds another layer of interactivity. The video further illustrates how varying Valence and Arousal inputs influence the generated terrain, showcasing environments such as Mountain, Desert, Plateau, and Coastal regions. Initially, we developed the system for four terrain types, but as discussed in the paper, it can be extended to generate up to eight terrain types. The video provides a clear visualization of how these mood-based inputs alter the virtual environments in real-time. Video Link (YouTube): https://youtu.be/GuNz8bGriLQ?si=RASaMvQOSGB-CYho


This repository contains code for generating synthetic terrain heightmaps from a trained Dual-Head VAE-GAN model (DH-CVAE-GAN).

## Sampling from Valence-Arousal Inputs

To generate a terrain from Valence (V) and Arousal (A), both in the range `[-1, 1]`.

- Given (V, A) and it generates the samples to folder output.


###  Usage

```bash
cd src

# Example 1: moderately positive and moderately aroused
python sample.py --valence 0.5 --arousal 0.2

# Example 2: negative valence, low arousal (more “desert-like”)
python sample_from_va.py --valence -0.8 --arousal -0.3




